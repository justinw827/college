lst = [ 1 ]
prod = 1
1.upto(5){|n| prod = prod * n; lst[n]=prod}
print lst
print "\n"
puts lst 