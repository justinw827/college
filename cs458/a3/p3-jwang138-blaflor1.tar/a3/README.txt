Group Members

Justin Wang jwang138@binghamton.edu
Beau Laflore blaflor1@binghamton.edu

The code was tested on bingsuns

Compile instructions

All files: make all
Client: make SslCli.java
Server: make SslServ.java
GenPass: make GenPass.java

Execution instructions

Client: make SslCli DOMAIN=<server_domain> PORT=<server_port>
Server: make SslServ PORT=<server_port>
GenPass: make GenPass