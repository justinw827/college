package studentCoursesBackup.util;

public interface FileDisplayInterface {
	public void printResults(String fileName);
}
