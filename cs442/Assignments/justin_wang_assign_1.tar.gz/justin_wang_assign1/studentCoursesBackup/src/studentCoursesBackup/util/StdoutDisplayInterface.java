package studentCoursesBackup.util;

public interface StdoutDisplayInterface {
	public void printToStdout();
}
