package genericCheckpointing.xmlStoreRestore;

import genericCheckpointing.util.SerializableObject;
import genericCheckpointing.util.MyAllTypesFirst;
import genericCheckpointing.util.MyAllTypesSecond;
import genericCheckpointing.util.FileProcessor;

import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;

public class XMLDeserialization implements StrategyI {

	@Override
	public Object check (Object placeholder, FileProcessor fp) {

		Class cls = null;
		Object obj = null;

		String discard = fp.readLine(); // Ignore first line
		String line = fp.readLine();
		
		String[] tokens1 = line.split("[\"<> ]+");
		String className = tokens1[3];
		
		try {
			cls = Class.forName(className);
			obj = cls.newInstance();
		} catch (ClassNotFoundException e) {
			System.out.println(className + " does not exist");
			e.printStackTrace();
		} catch (InstantiationException e) {
			System.out.println("Cannot instantiate " + cls);
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			System.out.println("Cannot access " + cls);
			e.printStackTrace();
		} finally {

		}

		while (!(line = fp.readLine()).equals("</DPSerialization>")) {
			if (line.equals(" </complexType>")) {

				String[] tokens2 = line.split("[\"<> ]+"); // Split by a quotation mark or by <>
				String typeName = tokens2[1]; // Get the type name, e.g. myInt 
				int begin = 2;
				String dataType = typeName.substring(begin, typeName.length()); // Get the 
				String val  = line.substring(line.indexOf(tokens2[4]), line.indexOf("/") - 1); 
				Field field = null;
				Method method = null;
					
				try {
					field = cls.getDeclaredField(typeName);
					Class signature = field.getType();
					method = cls.getMethod("set" + dataType, signature);
				} catch (NoSuchMethodException e) {
					System.out.println("Method not found: " + dataType);
					e.printStackTrace();
				} catch (NoSuchFieldException e) {
					System.out.println("Error reading method type: " + typeName);
					e.printStackTrace();
				}  finally {

				}
				
				try {
					
					switch (dataType) {
			            case "Int":  
			            	int dInt = deserInt(val);
			            	method.invoke(obj, dInt);
			                break;
			            case "String":
			            	String dString = val;
			            	method.invoke(obj, dString);
			            	break;
			            case "Long":
			            	long dLong = deserLong(val);
			            	method.invoke(obj, dLong);
			                break;
			            case "Bool":
			            	boolean dBool = deserBool(val);
			            	method.invoke(obj, dBool);
			                break;
			            case "ShortT":
			            	short dShort = deserShortT(val);
			            	method.invoke(obj, dShort);
			                break;
			            case "DoubleT":
			            	double dDouble = deserDoubleT(val);
			            	method.invoke(obj, dDouble);
			                break;
			            case "FloatT":
			            	float dFloat = deserFloatT(val);
			            	method.invoke(obj, dFloat);
			                break;
			            case "CharT":
			            	char dChar = deserCharT(val);
			            	method.invoke(obj, dChar);
			                break;
			            default: 
			            	break;
			        }

				} catch (IllegalAccessException e) {
					System.out.println("Error accessing method: " + method);
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					System.out.println("Error invoking: " + obj);
					e.printStackTrace();
				} finally {
					// Do something
				}					
			}
		}
				
		return obj;	
		
	}

	public int deserInt (String sIn) {
		return Integer.parseInt(sIn);
	}

	public boolean deserBool (String sIn) {
		return (new Boolean(sIn));
	}

	public long deserLong(String sIn) {
		return Long.parseLong(sIn);
	}

	public double deserDoubleT(String sIn) {
		return Double.parseDouble(sIn);
	}

	public float deserFloatT(String sIn) {
		return Float.parseFloat(sIn);
	}

	public short deserShortT(String sIn) {
		return Short.parseShort(sIn);
	}

	public char deserCharT(String sIn) {
		return sIn.charAt(0);
	}

	@Override
	public String toString() {
		String retVal = "genericCheckpointing.xmlStoreRestore.DeserializationStrategy.";
		return retVal;
	}
}