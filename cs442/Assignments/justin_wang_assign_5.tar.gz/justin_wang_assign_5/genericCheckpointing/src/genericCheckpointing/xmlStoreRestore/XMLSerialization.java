package genericCheckpointing.xmlStoreRestore;

import genericCheckpointing.util.SerializableObject;
import genericCheckpointing.util.FileProcessor;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;

public class XMLSerialization implements StrategyI {

	@Override
	public Object check(Object complexType, FileProcessor fp) {

		Field[] fieldList = complexType.getClass().getDeclaredFields();
		fp.writeToFile("<DPSerialization>\n" + " <complexType xsi:type=" + complexType.getClass() + ">");

		for (int i = 0; i < fieldList.length; i++) {

			String typeName = fieldList[i].getName();
			String dataType = fieldList[i].getType().toString();			
			int begin = 2;
			String actualType = typeName.toString().substring(begin, typeName.toString().length());
			try {
				Method method = complexType.getClass().getMethod("get" + actualType);
				Object newObj = method.invoke(complexType);

				String line;
				switch (dataType) {
		            case "Int":  
		            	line = serializeInt(typeName, dataType, (int) newObj);
						fp.writeToFile("  " + line);
		                break;
		            case "String":
		            	line = serString(typeName, dataType, (String) newObj);
						fp.writeToFile("  " + line);
		            	break;
		            case "Long":
		            	line = serLong(typeName, dataType, (long) newObj);
						fp.writeToFile("  " + line);
		                break;
		            case "Bool":
		            	line = serBool(typeName, dataType, (boolean) newObj);
						fp.writeToFile("  " + line);
		                break;
		            case "ShortT":
		            	line = serShortT(typeName, dataType, (short) newObj);
						fp.writeToFile("  " + line);
		                break;
		            case "DoubleT":
		            	line = serDoubleT(typeName, dataType, (double) newObj);
						fp.writeToFile("  " + line);
		                break;
		            case "FloatT":
		            	line = serFloatT(typeName, dataType, (float) newObj);
						fp.writeToFile("  " + line);
		                break;
		            case "CharT":
		            	line = serCharT(typeName, dataType, (char) newObj);
						fp.writeToFile("  " + line);
		                break;
		            default:
		                break;
		        }
					
			} catch (InvocationTargetException e) {
				System.out.println("Error invoking this target.");
				e.printStackTrace();			
			} catch (IllegalAccessException e) {
				System.out.println("Error accessing data.");
				e.printStackTrace();
			} catch (NoSuchMethodException e) {
				System.out.println("Error invoking method: get" + dataType);
				e.printStackTrace();
			} finally {
			
			}
		}

		fp.writeToFile(" </complexType>\n</DPSerialization>");

		return null;
	}

	public String serInt(String typeName, String dataType, int val) {
		StringBuilder line = new StringBuilder();
		line.append("<" + typeName + " xsi:type=\"xsd:" + dataType + "\">" + val + "</" + typeName + ">");
		return line.toString();
	}

	public String serString(String typeName, String dataType, String val) {
		StringBuilder line = new StringBuilder();
		line.append("<" + typeName + " xsi:type=\"xsd:string" + "\">" + val + "</" + typeName + ">");
		return line.toString();
	}

	public String serLong(String typeName, String dataType, long val) {
		StringBuilder line = new StringBuilder();
		line.append("<" + typeName + " xsi:type=\"xsd:" + dataType + "\">" + val + "</" + typeName + ">");
		return line.toString();
	}	

	public String serBool(String typeName, String dataType, boolean val) {
		StringBuilder line = new StringBuilder();
		line.append("<" + typeName + " xsi:type=\"xsd:" + dataType + "\">" + val + "</" + typeName + ">");
		return line.toString();
	}

	public String serShortT(String typeName, String dataType, short val) {
		StringBuilder line = new StringBuilder();
		line.append("<" + typeName + " xsi:type=\"xsd:" + dataType + "\">" + val + "</" + typeName + ">");
		return line.toString();
	}

	public String serDoubleT(String typeName, String dataType, double val) {
		StringBuilder line = new StringBuilder();
		line.append("<" + typeName + " xsi:type=\"xsd:" + dataType + "\">" + val + "</" + typeName + ">");
		return line.toString();
	}

	public String serFloatT(String typeName, String dataType, float val) {
		StringBuilder line = new StringBuilder();
		line.append("<" + typeName + " xsi:type=\"xsd:" + dataType + "\">" + val + "</" + typeName + ">");
		return line.toString();
	}

	public String serCharT(String typeName, String dataType, char val) {
		StringBuilder line = new StringBuilder();
		line.append("<" + typeName + " xsi:type=\"xsd:" + dataType + "\">" + val + "</" + typeName + ">");
		return line.toString();
	}
	
	@Override
	public String toString() {
		String retVal = "genericCheckpointing.xmlStoreRestore.SerializationStrategy.";
		return retVal;
	}
	
}