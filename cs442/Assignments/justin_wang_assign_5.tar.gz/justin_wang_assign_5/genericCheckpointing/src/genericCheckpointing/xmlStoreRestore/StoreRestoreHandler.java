package genericCheckpointing.xmlStoreRestore;

import genericCheckpointing.util.FileProcessor;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Field;

public class StoreRestoreHandler implements InvocationHandler {

	private FileProcessor fp;

	public StoreRestoreHandler(String fileName) {
		fp = new FileProcessor(fileName);
	}

	public Object invoke(Object proxy, Method mIn, Object[] args) {

		Object retVal = proxy;
		
		String methodName = mIn.getName();
		
		if (methodName.equals("writeObj")) {
			StrategyI strategy = (StrategyI) args[1];
			Object complexType = (SerializableObject) args[0];
			strategy.check(complexType, fp);

			retVal = true;
		} else if (methodName.equals("readObj")) {

			StrategyI strategy = (StrategyI) args[0];
			Object complexType = strategy.check(complexType, fp);

			retVal = obj;
		}
		
		return retVal;
	}

	public void openReader() {
		fp.openReader();
	}

	public void closeReader() {
		fp.closeReader();
	}

	public void openWriter() {
		fp.openWriter();
	}

	public void closeWriter() {
		fp.closeWriter();
	}

	public String toString() {
		String retVal = "genericCheckpointing.xmlStoreRestore.StoreRestoreHandler";
		return retVal;
	}

}