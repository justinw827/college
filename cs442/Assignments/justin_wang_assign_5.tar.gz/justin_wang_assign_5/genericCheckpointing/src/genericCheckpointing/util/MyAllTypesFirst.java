package genericCheckpointing.util;

public class MyAllTypesFirst extends SerializableObject {

	private int myInt;
	private long myLong;
	private String myString;
	private boolean myBool;
	
	/**
	  * Empty constructor
	  */
	public MyAllTypesFirst () {
		myInt = 0;
		myLong = 0;
		myString = " ";
		myBool = false;

	}
	
	/**
	  * Constructor that sets values of the 4 data members
	  * @param myIntIn value for myInt
	  * @param myLongIn value for myLong
	  * @param myStringIn value for myString
	  * @param myBoolIn value for myBool
	  */	
	public MyAllTypesFirst (int myIntIn, long myLongIn, String myStringIn, boolean myBoolIn) {

		myInt = myIntIn;
		myLong = myLongIn;
		myString = myStringIn;
		myBool = myBoolIn;
	
	}
	
	/**
	  * Returns the value of this objects myInt data member 
	  * @return myInt
	  */
	public int getInt () {
		return myInt;
	}
	
	/**
 	  * Sets the myInt data member to intIn
	  * @param intIn the number to set this int variable to
	  */
	public void setInt (int intIn) {
		myInt = intIn;
	}
	
	/**
	  * Returns the value of this objects myString data member
	  * @return myString
	  */
	public String getString () {
		return myString;
	}
	
	/**
 	  * Sets the myString data member to sIn
	  * @param sIn the string to set this string variable to
	  */
	public void setString (String sIn) {
		myString = sIn;
	}
	
	/**
	  * Returns the value of this objects myLong data member
	  * @return myLong
	  */
	public long getLong () {
		return myLong;
	}
	
	/**
	* Sets the myLong data member to longIn
	* @param longIn the number to set this long variable to
	*/
	public void setLong (long longIn) {
		myLong = longIn;
	}
	
	/**
	  * Returns the value of this objects myBool data member
	  * @return myBool
	  */
	public boolean getBool () {
		return myBool;
	}
	
	/**
 	  * Sets the myBool data member to bIn
	  * @param bIn the value to set this boolean variable to
	  */
	public void setBool(boolean bIn){
		myBool = bIn;
	}
	
	/**
	  * Override the equals operator to compare the actual contents
	  * of each object instead of the vector
	  * @param obj Object to be compared with
	  * @return true or false
	  */
	@Override
	public boolean equals (Object obj) {

		boolean retVal = false;

		if (myBool == ((MyAllTypesFirst) obj).getBool() && 
			myLong == ((MyAllTypesFirst) obj).getLong() &&
			 myString.equals(((MyAllTypesFirst) obj).getString()) && 
				myInt == ((MyAllTypesFirst) obj).getInt()) {
			retVal = true;
		} else {
			retVal = false;
		}

		return retVal;
	}
	
	/**
	  * Override toString() method for debugging
	  * @return Debug Statement
	  */
	@Override
	public String toString () {
		return String.format("MyAllTypesFirst \nInt: " + getInt() + "\nLong: " + getLong() + "\nBool: " + getBool() + "\nString: " + getString());
	}
}