package genericCheckpointing.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileNotFoundException;

/**
 * @author Ryan Heins
 */

public class FileProcessor {

	private String fileName;
	private FileReader fileRead;
	private BufferedReader buffRead;
	private FileWriter writer;

	/**
	* Constructor: sets up file reader and file buffer in try catch
	* @return Constructor - no return.
	* @return FileNotFoundException "Please try again, double check your file
	*	name/location."
	*/
	public FileProcessor(String fIn) {
		fileName = fIn;
	}

	public void openReader() {
		try {
			fileRead = new FileReader(fileName);
			buffRead = new BufferedReader(fileRead);
		} catch (FileNotFoundException err) {
			System.out.println("Please try again, double check your file name/location.");
			err.printStackTrace();
		} finally {

		}
	}

	/**
	*	Closes file once done reading
	* @return void - no return
	* @return IOException "Problem closing file after opening/reading."
	*/
	public void closeReader() {
		try {
			fileRead.close();
			buffRead.close();
		} catch (IOException err) {
			System.out.println("Problem closing file after opening/reading.");
			err.printStackTrace();
		}
	}

	public void openWriter() {
		try { 
            writer = new FileWriter(fileName, false);
        } catch (IOException e) {
            System.out.println("Error opening file to write.");
            e.printStackTrace();
        } finally {

        }
	}

	public void closeWriter() {
		try {
            writer.close();
        } catch (IOException  e) {
            System.out.println("Error closing writer.");
            e.printStackTrace();
        } catch (NullPointerException e) {
        	System.out.println("Error closing writer.");
            e.printStackTrace();
        } finally {

        }
	}

	/**
	*	Reads one line from the input file using fileRead and buffRead
	* and returns it as string
	*	@return String s - the next line from the file read by buffRead is returned
	*/
	public String readline() {
		String line;
		try {
			if ((line = buffRead.readLine()) != null) {
				return line;
			}
		} catch (IOException err) {
			System.out.println("Trouble reading a line from the input file.");
			err.printStackTrace();
		} finally {

		}

		return null;
	}

	public void writeLine(String line) {
		try {
            writer.write(line + "\n");
        } catch (IOException e) {
            System.out.println("Error writing to file.");
            e.printStackTrace();
        } finally {

        }
	}

}
