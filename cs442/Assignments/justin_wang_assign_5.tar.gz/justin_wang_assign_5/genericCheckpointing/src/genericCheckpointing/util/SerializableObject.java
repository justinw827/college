package genericCheckpointing.util;

/**
  * Empty base class. Used by MyAllTypesFirst and MyAllTypesSecond
  */
public class SerializableObject {

}