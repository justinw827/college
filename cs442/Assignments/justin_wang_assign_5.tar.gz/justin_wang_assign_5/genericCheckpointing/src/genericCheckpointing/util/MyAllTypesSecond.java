package genericCheckpointing.util;

public class MyAllTypesSecond extends SerializableObject {

	private double myDoubleT;
	private float myFloatT;
	private short myShortT;
	private char myCharT;
	
	/**
	  * Empty constructor
	  */
	public MyAllTypesSecond () {
		myDoubleT = 0;
		myFloatT = 0;
		myShortT = 0;
		myCharT = ' ';
	}
		
	/**
	  * Constructor that sets values of the 4 data members
	  * @param myDoubleTIn number to set double var to
	  * @param myFloatTIn number to set float var to
	  * @param myShortTIn number to set short var to
	  * @param myCharTIn character to set char var to
	  */
	public MyAllTypesSecond (double myDoubleTIn, float myFloatTIn, short myShortTIn, char myCharTIn) {

		myDoubleT = myDoubleTIn;
		myFloatT = myFloatTIn;
		myShortT = myShortTIn;
		myCharT = myCharTIn;

	}
	
	/**
	  * Returns the value of this objects myDoubleT data member
	  * @return myDoubleT	
	  */
	public double getDoubleT () {
		return myDoubleT;
	}
	
	/**
	  * Sets the myDoubleTT data member to dIn
	  * @param dIn is the value assigned to myDoubleT
	  */
	public void setDoubleT (double dIn) {
		myDoubleT = dIn;
	}	
	
	
	/**
	  * Returns the value of this objects myFloatT data member
	  * @return myFloatT	
	  */
	public float getFloatT () {
		return myFloatT;
	}
	
	/**
	  * Sets the myFloatT data member to fIn
	  * @param fIn is the value assigned to myFloatT
	  */
	public void setFloatT (float fIn) {
		myFloatT = fIn;
	}
	
	/**
	  * Returns the value of this objects myShortT data member
	  * @return myShortT	
	  */
	public short getShortT () {
		return myShortT;
	}
	
	/**
	  * Sets the myShortT data member to shortIn
	  * @param fIn is the value assigned to myShortT
	  */
	public void setShortT (short shortIn) {
		myShortT = shortIn;
	}
	
	/**
	  * Returns the value of this objects myCharT data member
	  * @return myCharT	
	  */
	public char getCharT () {
		return myCharT;
	}
	
	/**
	  * Sets the myCharT data member to cIn
	  * @param cIn the character to set this char variable to
	  */
	public void setCharT (char cIn) {
		myCharT = cIn;
	}
	
	/**
	  * Override the equals operator to compare the actual contents
	  * of each object instead of the vector
	  * @param obj Object to be compared with
	  * @return true or false
	  */
	@Override
	public boolean equals (Object obj) {

		boolean retVal = false;

		if (myDoubleT == ((MyAllTypesSecond) obj).getDoubleT() && 
			myFloatT == ((MyAllTypesSecond) obj).getFloatT() &&
			 myShortT == ((MyAllTypesSecond) obj).getShortT() && 
				myCharT == ((MyAllTypesSecond) obj).getCharT()) {
			retVal = true;
		} else {
			retVal = false;
		}

		return retVal;
	}
	
	/**
	  * Override toString() method for debugging
	  * @return Debug Statement
	  */
	@Override
	public String toString(){
		return String.format("MyAllTypesSecond \nDouble: " + getDoubleT() + "\nFloat: " + getFloatT() + "\nShort: " + getShortT() + "\nChar: " + getCharT());
	}
}