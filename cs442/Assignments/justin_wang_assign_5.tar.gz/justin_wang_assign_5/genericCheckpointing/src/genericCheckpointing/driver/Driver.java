package genericCheckpointing.driver;

import genericCheckpointing.server.RestoreI;
import genericCheckpointing.server.StoreI;
import genericCheckpointing.server.StoreRestoreI;
import genericCheckpointing.util.FileProcessor;
import genericCheckpointing.util.MyAllTypesFirst;
import genericCheckpointing.util.MyAllTypesSecond;
import genericCheckpointing.util.ProxyCreator;
import genericCheckpointing.util.SerializableObject;
import genericCheckpointing.xmlStoreRestore.StoreRestoreHandler;
import genericCheckpointing.xmlStoreRestore.StrategyI;
import genericCheckpointing.xmlStoreRestore.XMLDeserialization;
import genericCheckpointing.xmlStoreRestore.XMLSerialization;

import java.util.ArrayList;
import java.util.Random;
import java.lang.System;
import java.lang.reflect.InvocationHandler;

// import the other types used in this file

public class Driver {
    
    public static void main (String[] args) {

    	// arg0 = <mode>; arg1 = <N>; arg2 = <checkpointFile>
    	// <mode> : "serdeser" or "deser"
    	// <N> : if "serdeser" mode, NUM_OF_OBJECTS of MyAllTypesFirst MyAllTypesSecond each 
    	//		 if "deser" mode, number of objects to be deserialized
    	// <checkpointFile> : Name of the checkpoint file
    	if (args.length != 3 || args[0].equals("${arg0}") || args[1].equals("${arg1}") || args[2].equals("${arg2}")) {
			System.out.println("Error: Incorrect number of arguments. Program accepts 3 arguments.");
			System.exit(0);
		}
		
		// Read the value of checkpointFile from the command line
		String checkpointFile = args[2];
		
		ProxyCreator pc = new ProxyCreator();
		
		// create an instance of StoreRestoreHandler (which implements
		// the InvocationHandler
		
		// create a proxy
		StoreRestoreHandler srHandler = new StoreRestoreHandler(checkpointFile);

		StoreRestoreI cpointRef = (StoreRestoreI) pc.createProxy(
									 new Class[] {
									     StoreI.class, RestoreI.class
									 }, 
									 srHandler
									 );
			
		// FIXME: invoke a method on the handler instance to set the file name for checkpointFile and open the file



		MyAllTypesFirst myFirst;
		MyAllTypesSecond  mySecond;

		// Use an if/switch to proceed according to the command line argument
		// For deser, just deserliaze the input file into the data structure and then print the objects
		// The code below is for "serdeser" mode
		// For "serdeser" mode, both the serialize and deserialize functionality should be called.

		String mode = args[0];
		// Get N from command line
		int NUM_OF_OBJECTS = Integer.parseInt(args[1]); 

		if (mode.equals("serdeser")) {
			StrategyI serialize = new XMLSerialization();
			srHandler.openWriter();

			// create a data structure to store the objects being serialized
		    // NUM_OF_OBJECTS refers to the count for each of MyAllTypesFirst and MyAllTypesSecond
			// passed as "N" from the command line.

			ArrayList<SerializableObject> vector_old = new ArrayList();
			

			if (NUM_OF_OBJECTS < 1) {
				System.out.println("N must be greater than 0.");
				exit(1);
			}

			for (int i = 0; i < NUM_OF_OBJECTS; i++) {

			    // FIXME: create these object instances correctly using an explicit value constructor
			    // use the index variable of this loop to change the values of the arguments to these constructors

				int newInt = (int) (Math.random() + 42);
				long newLong = (long) (Math.random() + 42424);
				String newString = "Hello";
				boolean newBool = true;

			    myFirst = new MyAllTypesFirst(newInt, newLong, newString, newBool);

			    Random rand = new Random();
			    double newDouble = (double) (Math.random() + 11111);
			    float newFloat = (float) (Math.random() + 123456);
			    short newShort = (short) (Math.random() + 2345);
			    char newChar = (char) ('a' + rand.nextInt(26));

			    mySecond = new MyAllTypesSecond(newDouble, newFloat, newShort, newChar);

			    // FIXME: store myFirst and mySecond in the data structure
			    // authID (13 and 17) is not being used in the assignment, but
			    // is left for future use. 

			    vector_old.add(myFirst);
			    vector_old.add(mySecond);

			    ((StoreI) cpointRef).writeObj(myFirst, 13,  "XML");
			    ((StoreI) cpointRef).writeObj(mySecond, 17, "XML");

			}

			srHandler.closeWriter();

		}

		// Deserialization

		StrategyI deserialize = new XMLDeserialization();
		srHandler.openReader();
		ArrayList<SerializableObject> vector_new = new ArrayList();

		SerializableObject myRecordRet;

		// create a data structure to store the returned ojects
		for (int j = 0; j < 2*NUM_OF_OBJECTS; j++) {

		    myRecordRet = ((RestoreI) cpointRef).readObj("XML");
		    // FIXME: store myRecordRet in the vector (or arrayList)
		    vector_new.add(myRecordRet);
		}

		// FIXME: invoke a method on the handler to close the file (if it hasn't already been closed)
		srHandler.closeReader();

		// FIXME: compare and confirm that the serialized and deserialzed objects are equal. 
		// The comparison should use the equals and hashCode methods. Note that hashCode 
		// is used for key-value based data structures

		if (mode.equals("serdeser")) {	
			int mismatches = 0;
			for (int i = 0; i < 2*NUM_OF_OBJECTS; i++){
				
				if (!(vector_old.get(i).equals(vector_new.get(i)))) {

					System.out.println("Mismatch:");
					System.out.println("vector_old: " + vector_old.get(i));
					System.out.println("vector_new: " + vector_new.get(i));					

					mismatches++;
				}
			}

			System.out.println("Mismatches: " + mismatches);
			
		}

    
    }
}